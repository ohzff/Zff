# 撞FuFu

运行环境：

- [ ] Windows
- [x] Linux
- - [x] ARM
- - [x] X86_64
- [x] MacOS
- - [x] X86_64


# 下载

```bash
./LanGong install github langong-dev/Zff
```

# 运行

```bash
./LanGong run Zff
```

错误报告: ```langonginc@yeah.net```
