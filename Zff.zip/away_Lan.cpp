#include<iostream>
#include<cstdio>
using namespace std;
int main(){
	freopen("level.dll","w",stdout);
	system("clear");
	printf("%d",-1);
	freopen("palseF.dll","w",stdout);
	system("clear");
	cout<<0;
	freopen("palseZ.dll","w",stdout);
	system("clear");
	cout<<0;
	freopen("user.dll","w",stdout);
	system("clear");
	cout<<"LanGong";
	return 0;
}
